CREATE TABLE `ss-user`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `avatar` VARCHAR(300) COMMENT '头像',
    `nickname` VARCHAR(64) COMMENT '用户昵称',
    `phone_number` VARCHAR(64) COMMENT '手机号',
    `description` VARCHAR(100) COMMENT '描述',
    `email` VARCHAR(64) COMMENT '邮箱',
    `sex` TINYINT(1) COMMENT '性别,0女,1男',
    `status` TINYINT(1) DEFAULT 0 COMMENT '状态 0:正常,1:禁用',

    `update_time` DATETIME COMMENT '更新时间',
    `update_by_id` BIGINT(20) COMMENT '更新人的ID',
    `create_time` DATETIME COMMENT '创建时间',
    `create_by_id` BIGINT(20) COMMENT '创建人的ID',
    `is_delete` TINYINT(1) DEFAULT 0 COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '用户信息详情表';

