create table `ss_payment_record` (
      `id` bigint (20),
      `pay_type` tinyint (1),
      `pay_type_title` varchar (192),
      `total_amount` Decimal (12),
      `receipt_amount` Decimal (12),
      `invoice_amount` Decimal (12),
      `buyer_pay_amount` Decimal (12),
      `point_amount` Decimal (12),
      `refund_fee` Decimal (12),
      `charset` varchar (48),
      `method` varchar (192),
      `sign` varchar (1152),
      `auth_app_id` varchar (96),
      `version` varchar (24),
      `sign_type` varchar (48),
      `trade_no` varchar (192),
      `app_id` varchar (96),
      `out_trade_no` varchar (192),
      `out_biz_no` varchar (192),
      `buyer_id` varchar (48),
      `seller_id` varchar (96),
      `trade_status` varchar (96),
      `notify_type` varchar (192),
      `notify_id` varchar (384),
      `subject` varchar (768),
      `body` varchar (1536),
      `fund_bill_list` varchar (1536),
      `vocher_detail_list` varchar (1536),
      `passback_params` varchar (1536),
      `gmt_create` datetime ,
      `gmt_payment` datetime ,
      `gmt_refund` datetime ,
      `gmt_close` datetime ,
      `timestamp` datetime ,
      `notify_time` datetime ,
      `update_time` datetime ,
      `update_by_id` bigint (20),
      `create_time` datetime ,
      `create_by_id` bigint (20),
      `is_delete` tinyint (1)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '支付记录信息表';


CREATE TABLE `ss_refund_record` (
    `id` bigint(20) NOT NULL COMMENT '主键ID',

    `order_id` bigint(20) DEFAULT NULL COMMENT '订单ID',
    `out_trade_no` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '订单号',

    `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',

    `buyer_name` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '买家名称',
    `buyer_phone_number` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '买家联系电话',
    `buyer_reason` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '买家申请内容',

    `status` tinyint(1) DEFAULT '0' COMMENT '退款申请状态,0买家申请提交,1卖家处理,2系统退款,3完成,4系统退款异常,5卖拒绝退款,6买家取消退款',

    `handle_reply` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '卖家回复内容',

    `price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '本次退款额，精确到小数点后 2 位',

    `type` tinyint(1) DEFAULT NULL COMMENT '退款类型:0系统自动退款, 1用户发起退款, 2商家发起退款',

    `update_time` datetime DEFAULT NULL COMMENT '更新时间',
    `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
    `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='申请退款信息表';



CREATE TABLE `ss_refund_operation_record`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `order_id` BIGINT(20) COMMENT '主订单主键',
    `before` tinyint(1) DEFAULT '0' COMMENT '改变前状态',
    `after` tinyint(1) DEFAULT '0' COMMENT '改变后状态',
    `note` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '注释或备注',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '申请退款操作记录信息表';


CREATE TABLE `ss_trade_refund_record` (
   `id` bigint(20) NOT NULL COMMENT '主键ID',
   `refund_amount` decimal(10,2) DEFAULT NULL COMMENT '退款金额。 需要退款的金额，该金额不能大于订单金额，单位为元，支持两位小数',
   `refund_fee` decimal(10,2) DEFAULT NULL COMMENT '退款总金额。指该笔交易累计已经退款成功的金额，单位为元，支持两位小数',
   `send_back_fee` decimal(10,2) DEFAULT NULL COMMENT '本次商户实际退回金额。说明：如需获取该值，需在入参query_options中传入 refund_detail_item_list，单位为元，支持两位小数',
   `refund_reason` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '退款原因说明。商家自定义，将在会在商户和用户的pc退款账单详情中展示',
   `out_request_no` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '退款请求号。标识一次退款请求，需要保证在交易号下唯一，如需部分退款，则此参数必传',
   `code` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '网关返回码',
   `msg` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '网关返回码描述',
   `sub_code` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务返回码',
   `trade_no` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '支付宝交易号，支付宝交易凭证号',
   `out_trade_no` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '商户订单号',
   `buyer_logon_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户的登录id',
   `fund_change` varchar(8) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '本次退款是否发生了资金变化',
   `refund_detail_item_list` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '退款使用的资金渠道。只有在签约中指定需要返回资金明细，或者入参的query_options中指定时才返回该字段信息。',
   `store_name` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '交易在支付时候的门店名称',
   `buyer_user_id` varchar(32) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '买家在支付宝的用户id',
   `sign` varchar(384) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '签名,详情可查看,异步返回结果的验签',
   `gmt_refund_pay` datetime DEFAULT NULL COMMENT '退款时间',

   `update_time` datetime DEFAULT NULL COMMENT '更新时间',
   `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
   `create_time` datetime DEFAULT NULL COMMENT '创建时间',
   `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
   `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

   PRIMARY KEY (`id`)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='退款存根信息表';