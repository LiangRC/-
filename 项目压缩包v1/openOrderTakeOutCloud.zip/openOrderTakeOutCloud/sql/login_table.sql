CREATE TABLE `ss_login_record`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `user_id` BIGINT(20) COMMENT '绑定用户主键ID',
    `type` VARCHAR(64) COMMENT '登录枚举',
    `ip` VARCHAR(64) COMMENT '登录的IP地址',
    `address` VARCHAR(200) COMMENT '登录IP归属地址',
    `pro_code` BIGINT(10) COMMENT '省级行政代码',
    `city_code` BIGINT(10) COMMENT '市级行政代码',
    `way_type` TINYINT(1) COMMENT '登录方式:0密码登录,1短信登录,2微信登录',
    `browser_name` VARCHAR(200) COMMENT '登录的浏览器名',
    `browser_version` VARCHAR(200) COMMENT '登录的浏览器版本',
    `manufacturer` VARCHAR(200) COMMENT '登录的浏览器生产厂商',
    `device_type` VARCHAR(200) COMMENT '登录设备类型',
    `system_name` VARCHAR(200) COMMENT '登录操作系统名',
    `system_group` VARCHAR(200) COMMENT '登录设备的操作系统家族',

    `create_time` DATETIME COMMENT '创建时间',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '登录记录表';