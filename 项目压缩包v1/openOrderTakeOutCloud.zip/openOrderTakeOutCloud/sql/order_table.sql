CREATE TABLE `ss_order_detail`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `status` tinyint(1) DEFAULT '0' COMMENT '订单状态, 0创建,1待付款,2后厨制作中,3制作完成待派送,4正在派送中,5已派送完成,6已完成,7已取消,8超时未支付已自动取消,9退款申请,10退款成功 ',
    `original_price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '订单原始价',
    `freight_price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '运费',
    `coupon_price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '优惠要减免总价',
    `product_total_number` INT(16) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '该订单产品总数',
    `bill_price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '优惠要减免总价',
    `out_trade_no` VARCHAR(64) COMMENT '订单号',
    `subject` VARCHAR(64) COMMENT '订单标题',
    `body` VARCHAR(64) COMMENT '订单内容',
    `remark` VARCHAR(256) COMMENT '用户备注',
    `phone_number` VARCHAR(64) COMMENT '收货人手机号',
    `address_book_id` BIGINT(20) COMMENT '地址绑定的主键',
    `consignee_name` VARCHAR(64) COMMENT '收货人姓名',
    `detail` VARCHAR(64) COMMENT '详细地址',
    `sex` tinyint(1) DEFAULT '0' COMMENT '性别,0女,1男',
    `label` VARCHAR(32) COMMENT '标签,0默认,1家,2学校,3公司,4其他',
    `user_id` BIGINT(20) COMMENT '订单归属用户的主键',

    `update_time` datetime DEFAULT NULL COMMENT '更新时间',
    `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
    `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '订单详情信息表';


CREATE TABLE `ss_child_order_detail`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `order_id` BIGINT(20) COMMENT '主订单主键',
    `product_id` BIGINT(20) COMMENT '产品主键',
    `name` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品名称',
    `value` VARCHAR(64) COMMENT '产品属性',
    `image_def_url` varchar(400) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品主图片',
    `price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品价格',
    `amount` INT(16) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品购买数量',
    `original_price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '订单原始价',

    `update_time` datetime DEFAULT NULL COMMENT '更新时间',
    `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
    `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '订单详情信息表';

CREATE TABLE `ss_order_operation_record`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `order_id` BIGINT(20) COMMENT '主订单主键',
    `before` tinyint(1) DEFAULT '0' COMMENT '改变前状态',
    `after` tinyint(1) DEFAULT '0' COMMENT '改变后状态',
    `note` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '注释或备注',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '订单操作记录信息表';

