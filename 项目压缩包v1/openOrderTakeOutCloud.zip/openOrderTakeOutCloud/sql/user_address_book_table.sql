CREATE TABLE `ss_user_address_book`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `user_id` BIGINT(20) COMMENT '绑定用户主键ID',
    `consignee_name` VARCHAR(64) COMMENT '收货人姓名',
    `phone_number` VARCHAR(64) COMMENT '手机号',
    `sex` TINYINT(1) COMMENT '性别,0女,1男',
    `detail` VARCHAR(200) COMMENT '详细地址',
    `label` VARCHAR(128) COMMENT '标签',
    `isDefault` TINYINT(1) COMMENT '是否默认,0否,1是',

    `update_time` DATETIME COMMENT '更新时间',
    `update_by_id` BIGINT(20) COMMENT '更新人的ID',
    `create_time` DATETIME COMMENT '创建时间',
    `create_by_id` BIGINT(20) COMMENT '创建人的ID',
    `is_delete` TINYINT(1) COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '用户地址簿信息表';