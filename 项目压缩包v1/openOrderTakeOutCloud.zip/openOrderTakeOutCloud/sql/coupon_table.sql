CREATE TABLE `ss_coupon`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `batch_id` BIGINT(20) COMMENT '批次表主键',

    `price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '优惠券面额',
    `threshold` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '消费门槛',
    `status` tinyint(1) DEFAULT '0' COMMENT '批次表状态: 0未使用, 1已使用, 2过期, 3冻结, 4异常',
    `coupon_name` VARCHAR(64) COMMENT '优惠券名称',
    `description` VARCHAR(512) COMMENT '优惠券描述',

    `start_time` DATETIME COMMENT '使用起始时间',
    `end_time` DATETIME COMMENT '使用截止时间',

    `user_id` BIGINT(20) COMMENT '领取该券的用户主键',
    `use_time` DATETIME COMMENT '优惠券被核销(使用)时间*',
    `use_out_trade_no` VARCHAR(64) COMMENT '核销(使用)该优惠券订单号',

    `update_time` datetime DEFAULT NULL COMMENT '更新时间',
    `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
    `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '优惠券详情信息表';


CREATE TABLE `ss_coupon_batch_detail`
(
    `id` BIGINT(20) NOT NULL COMMENT '主键ID',

    `coupon_name` VARCHAR(64) COMMENT '优惠券名称',
    `description` VARCHAR(512) COMMENT '优惠券描述',
    `status` tinyint(1) DEFAULT '0' COMMENT '批次表状态: 0未使用, 1已使用, 2过期, 3冻结, 4异常',
    `threshold` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '消费门槛',
    `price` decimal(10,2) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '优惠券面额',
    `total_count` INT(16) COMMENT '优惠券总量',
    `receive_count` INT(16) COMMENT '优惠券已领取量',
    `start_time` DATETIME COMMENT '使用起始时间',
    `end_time` DATETIME COMMENT '使用截止时间',

    `update_time` datetime DEFAULT NULL COMMENT '更新时间',
    `update_by_id` bigint(20) DEFAULT NULL COMMENT '更新人的ID',
    `create_time` datetime DEFAULT NULL COMMENT '创建时间',
    `create_by_id` bigint(20) DEFAULT NULL COMMENT '创建人的ID',
    `is_delete` tinyint(1) DEFAULT '0' COMMENT '删除标志（0代表未删除，1代表已删除）',

    PRIMARY KEY (`id`)
)
    ENGINE=INNODB CHARSET=utf8mb4 COLLATE=utf8mb4_bin  COMMENT '优惠券批次详情信息表';

