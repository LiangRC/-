module.exports = {
    module:{
        rules: [
            {
                test: /\.scss$/,
                loaders: ['style','css','sass']
            }
        ]
    }
}