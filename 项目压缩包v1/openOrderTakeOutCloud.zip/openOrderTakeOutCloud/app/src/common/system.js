

export default {

    // 服务器网络地址
    apiUrl : "http://api.starsh.top:8898/",

    // 令牌存储本地存储 Key
    TOKEN_KEY : "starshine-token",

    // 加密 key
    // secruityKey: '7396101173961011',
    secruityKey: '2Vqz1yy35s5Uo776',

    /**输出给服务加密密钥*/
    outServiceAesKey: "7g4MLt0V7TY939x4",

    /**接收服务的加密数据进行解密的密钥*/
    inputServiceAesKey: "2Vqz1yy35s5Uo776",

    // 用户信息
    STARSHINT_TOP_USER_INFO : "STARSHINT_TOP_USER_INFO",

}
