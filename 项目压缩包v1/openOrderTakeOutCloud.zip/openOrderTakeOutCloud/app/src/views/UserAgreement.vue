<template>
    <div>
        <H3>用户协议</H3>
        <p>哔哩哔哩干杯~</p>
    </div>
</template>

<script>
export default {
    name: "UserAgreement"
}
</script>

<style scoped>

</style>