package top.starshine;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/29  下午 10:59  周五
 * @Description: hello world
 */
@Slf4j
@SpringBootTest
public class JUCTest {

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    ThreadPoolExecutor threadPoolExecutor;

    @Test
    void test1() throws ExecutionException, InterruptedException {


        new Thread(()->{
            CompletableFuture<Void>[] array = new CompletableFuture[10000];
            for (int i = 0; i < array.length; i++) {
                array[i] = CompletableFuture.runAsync(()->{
                    log.info("响应结果=>{}",restTemplate.getForObject("http://localhost:8080/say",String.class));
                });
            }
            try {
                CompletableFuture.allOf(array).get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }).start();

        new Thread(()->{
            CompletableFuture<Void>[] array = new CompletableFuture[10000];
            for (int i = 0; i < array.length; i++) {
                array[i] = CompletableFuture.runAsync(()->{
                    log.info("响应结果=>{}",restTemplate.getForObject("http://localhost:8080/say",String.class));
                });
            }
            try {
                CompletableFuture.allOf(array).get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }).start();
    }


}
