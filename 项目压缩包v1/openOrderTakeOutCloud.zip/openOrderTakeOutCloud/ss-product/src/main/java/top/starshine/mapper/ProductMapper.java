package top.starshine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.starshine.commons.entity.product.Product;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/27  下午 9:59  周三
 * @Description: hello world
 */
public interface ProductMapper extends BaseMapper<Product> {
}
