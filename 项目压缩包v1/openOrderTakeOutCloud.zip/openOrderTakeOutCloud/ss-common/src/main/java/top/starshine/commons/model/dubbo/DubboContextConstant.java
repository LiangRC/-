package top.starshine.commons.model.dubbo;

/**
 * <h3>dubbo 过滤器常量</h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/26  下午 6:01  周二
 * @Description: hello world
 */
public final class DubboContextConstant {

    public static final String USER_DETAIL_KEY = "starshine";
    public static final String USER_AES_KEY = "2Vqz1yy35s5Uo776";

}
