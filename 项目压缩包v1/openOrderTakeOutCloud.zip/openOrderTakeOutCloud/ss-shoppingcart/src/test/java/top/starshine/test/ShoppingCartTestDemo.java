package top.starshine.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import top.starshine.commons.entity.user.User;
import top.starshine.commons.handle.ThreadLocalCache;
import top.starshine.service.ShoppingCartService;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/28  下午 6:54  周四
 * @Description: hello world
 */
@SpringBootTest
public class ShoppingCartTestDemo {

    @Autowired
    ShoppingCartService shoppingCartService;

    @Test
    void test2(){
        ThreadLocalCache.put(new User().setId(6666L));
        shoppingCartService.subtract(1397850851245600769L,"不要辣2");
    }

    @Test
    void test1(){
        ThreadLocalCache.put(new User().setId(6666L));
        shoppingCartService.add(1397850851245600769L,"不要辣6");
    }


}
