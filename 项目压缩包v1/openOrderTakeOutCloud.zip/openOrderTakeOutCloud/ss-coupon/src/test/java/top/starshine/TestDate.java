package top.starshine;

import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import top.starshine.commons.entity.coupon.Coupon;
import top.starshine.commons.entity.coupon.CouponBatchDetail;
import top.starshine.service.CouponBatchDetailService;
import top.starshine.service.CouponService;

import java.util.List;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/8/5  下午 4:56  周五
 * @Description: 创作不容易, 记得关注点赞打赏一键三连
 */
@SpringBootTest
public class TestDate {

    //@Autowired
    //private CouponService couponService;
    @Autowired
    private CouponBatchDetailService couponBatchDetailService;

    @Test
    void test2(){
        List<CouponBatchDetail> list = couponBatchDetailService.findList();
        System.out.println(list);
    }


    @Test
    void test1(){
        //new LambdaUpdateChainWrapper<>(couponService.getBaseMapper())
        //        .set(Coupon::getStatus, 0)
        //        .set(Coupon::getUseOutTradeNo, "")
        //        .set(Coupon::getUseTime, null)
        //        .eq(Coupon::getId, 1555448346099458049L)
        //        .update();
    }
}
