package top.starshine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.starshine.commons.entity.login.LoginRecord;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/27  下午 5:53  周三
 * @Description: hello world
 */
public interface LoginRecordMapper extends BaseMapper<LoginRecord> {
}
