package top.starshine;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import top.starshine.commons.model.web.http.HttpClientService;

import java.util.Map;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/27  下午 5:19  周三
 * @Description: hello world
 */
@SpringBootTest
@Slf4j
public class TestAsync {

    @Autowired
    HttpClientService httpClientService;


    @Test
    void test1(){
        Map<String, String> ipAddress = httpClientService.getIpAddress("192.168.1.2");
        System.out.println(ipAddress);
    }

}
