package top.starshine;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import top.starshine.commons.entity.coupon.Coupon;
import top.starshine.commons.entity.coupon.RollbackCouponDto;
import top.starshine.mq.producer.PaymentSendMQ;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/8/5  下午 5:05  周五
 * @Description: 创作不容易, 记得关注点赞打赏一键三连
 */
@SpringBootTest
public class TestRollbackCouponUse {

    @Autowired
    private PaymentSendMQ paymentSendMQ;

    @Test
    void test1(){
        paymentSendMQ.sendRollbackCouponUse(
                new RollbackCouponDto(1540278005366652929L, "202208051555467994828349442")
        );

    }
}
